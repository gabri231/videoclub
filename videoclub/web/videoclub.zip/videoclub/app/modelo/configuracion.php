<?php
	///////////////////////////////////////////////
	//	DEFICION DE LA PAGINA WEB.
	// 	Si la pagina es:    http://localhost/carpeta/carpeta/pagina/videoclub/index.php
	// 	Entonces se deberia configurar: define("PAGINA","/carpeta/carpeta/pagina/videoclub/");
	//
	//	En este caso es:	http://localhost/videoclub/index.php
	define("PAGINA","/videoclub/");
	///////////////////////////////////////////////
	//	PARAMETROS DE LA BASE DE DATOS
	define("PARAMETROS","host=127.0.0.1 dbname=videoclub user=videoclub password=videoclub");
	///////////////////////////////////////////////
?>