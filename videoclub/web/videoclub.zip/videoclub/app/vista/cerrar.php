<?php
	////////////////////////////////////////////
	// HEADER DE LA PAGINA
	require_once 'app/vista/includes/header_user_no_menu.php';
	// FIN HEADER DE LA PAGINA
	////////////////////////////////////////////
?>
<div style="background: #3F3C00" class="entrada">
	<div class="infoRoja">
	    ADIOS :(<br>Se esta cerrando su sesión...<br>
	    <img height="250" src="<?php echo PAGINA?>web/img/adios.jpg">
	</div>
</div>

<?php
	////////////////////////////////////////////
	// FOOTER DE LA PAGINA
	require_once 'app/vista/includes/footer.php';
	// FIN FOOTER DE LA PAGINA
	////////////////////////////////////////////
?>