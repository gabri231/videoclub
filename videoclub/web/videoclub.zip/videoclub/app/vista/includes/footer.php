    <!-- FIN CONTENIDO A INCLUIR -->
    </div><!-- FIN DIV CUERPO -->
    <div id="final">
      <div class="footer"></div>
      <span id="copyright"> Copyright &copy; 2005. Your copyright info here.</span>
      <ul id="menuFinal">
        <li><a href="<?php echo PAGINA; ?>index.php" title="home">home</a></li>
        <li><a href="<?php echo PAGINA; ?>index.php/peliculas" title="peliculas">peliculas</a></li>
        <li><a href="<?php echo PAGINA; ?>index.php/contacto" title="contacto">contacto</a></li>
        <li><a href="<?php echo PAGINA; ?>index.php/enlaces" title="enlaces">enlaces</a></li>
      </ul>
    </div>
  </div><!-- FIN DIV CONTAINER -->

</body>
</html>